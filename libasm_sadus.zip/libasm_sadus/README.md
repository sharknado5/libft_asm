The binary that you get is a testing main for the libasm.
If nothing is working, please check your nasm version
